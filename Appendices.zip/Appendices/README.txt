This zipped file contains multiple files, as follows:

1. List of questions for questionnaire (questionnaire_questionlist.docx)
2. Questionnaire data (questionnaire_data_cleaned.csv)
2. List of questions for interview (Interview_guide.docx)
3. List of interviewees (interviewees.docx)


Disclaimer: most of the contents are in Indonesian language.